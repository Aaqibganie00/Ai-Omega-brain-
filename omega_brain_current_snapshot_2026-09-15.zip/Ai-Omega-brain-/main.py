"""
MAIN - runs the MVP against the 3 benchmark tasks from the spec (section 18):
  TEST 1: Create a simple web application.
  TEST 2: Create a small 3D game prototype.
  TEST 3: Analyze a complex technical problem and produce a verified solution.
"""

from omega_core import OmegaCore


def run_benchmark():
    requests = [
        "Create a simple web application with a backend and frontend",
        "Create a small 3D game prototype with a player controller",
        "Analyze the tradeoffs of microservices vs monolith and give a verified report",
    ]

    summary = []
    for req in requests:
        core = OmegaCore(project_memory_path=f"memory_{abs(hash(req)) % 1000}.json")
        result = core.handle_request(req)
        summary.append({"request": req, "status": result["status"]})

    print("\n\n=== BENCHMARK SUMMARY ===")
    for s in summary:
        print(f"[{s['status']}] {s['request']}")


if __name__ == "__main__":
    run_benchmark()
