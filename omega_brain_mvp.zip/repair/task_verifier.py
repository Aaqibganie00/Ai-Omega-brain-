"""
SELF-CORRECTION LAYER — TASK VERIFIER
-------------------------------------------
Separate from repair.critic.Critic (which judges the *quality* of the
change) and separate from verification.VerificationEngine (Phase 1's
code-compiles check). This checks objective, file-system-level evidence
that the task's stated requirements are actually met - required files
exist, and the real test result (not a model's claim) passed.
"""

from .schemas import TaskVerificationResult


class TaskVerifier:
    def verify(self, tool_registry, required_files: list, test_result: dict) -> TaskVerificationResult:
        checks = {}

        for path in required_files or []:
            try:
                tool_registry.impl.read_file(path)
                checks[f"file_exists:{path}"] = True
            except Exception:
                checks[f"file_exists:{path}"] = False

        checks["tests_passed"] = bool(test_result.get("passed"))

        passed = all(checks.values()) if checks else bool(test_result.get("passed"))
        missing = [k for k, v in checks.items() if not v]
        detail = "All checks passed." if passed else f"Failed checks: {', '.join(missing)}"

        return TaskVerificationResult(passed=passed, checks=checks, detail=detail)
