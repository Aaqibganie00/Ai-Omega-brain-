# Omega Brain — MVP

A real, runnable skeleton of the architecture described in the spec:
Omega Core → Task Planner (DAG) → Model Router → Specialized Workers →
Memory (working/project/execution) → Verification Engine → AI Heart →
Error Recovery Engine.

## Run it

```bash
python3 main.py
```

This runs the three benchmark tasks from the spec's own section 18:
1. "Create a simple web application"
2. "Create a small 3D game prototype"
3. "Analyze a complex technical problem and produce a verified solution"

Each request is decomposed into a dependency graph, executed batch by batch
(parallel where dependencies allow), routed to a specialized worker, checked
by the verification engine, and evaluated by the AI Heart before being
marked done. Failures trigger the error recovery engine instead of blind
retries.

## What's real vs. what's mocked

**Real (fully functional):**
- Task DAG with dependency resolution and parallel-batch scheduling
- Model/agent router with capability matching and performance-based selection
- Three memory layers (working, project/persisted, execution log)
- Verification engine that actually compiles generated Python and validates
  HTML shape (not a pretend "trust it" step)
- AI Heart as a real constraints/retry-budget checker, separate from
  technical correctness
- Error recovery engine that reads execution history and picks a strategy
  (retry / switch backend / escalate) rather than looping forever

**Mocked (clearly labeled in code, `workers.py`):**
- The actual "intelligence" of each worker. There's no external model API
  wired in here, so workers return deterministic template output instead of
  calling a real LLM. The `CodingWorker` does return two genuinely
  compilable snippets (a Flask backend, an HTML page) so the verification
  step has real material to check.
- The task planner is rule-based for 3 request categories, not an LLM. See
  `LLMTaskPlanner` stub in `task_planner.py` for where a real model call
  would plug in — same interface, drop-in replacement.

## What would be needed for the real thing

- API keys/credentials for one or more real model backends, wired into
  `workers.py` (`BaseWorker.run` → real API call)
- A sandboxed execution environment for running/testing generated code
  beyond syntax checks (this MVP only compiles, it doesn't execute)
- Real tool integrations (file system, git, browser, build systems) behind
  the `ModelBackend`-style permission boundary the spec calls for
- For 3D/game or Android output specifically: actual engine toolchains
  (Unity/Godot/Android SDK) invoked from a build worker — no engine is
  installed in this environment, so game/app output here is pseudocode,
  not a compiled project. This distinction matters and the code doesn't
  pretend otherwise.

## File map

- `omega_core.py` — coordinator, ties everything together
- `task_planner.py` — request → task DAG
- `router.py` — model/agent selection abstraction
- `workers.py` — specialized worker implementations (mocked backends)
- `memory.py` — working / project / execution memory
- `verification.py` — verification engine + AI Heart
- `error_recovery.py` — failure-handling strategy selection
- `main.py` — runs the 3 benchmark tasks
