"""
QUALITY CONTROL LAYER — FILE-CHANGE AUDIT
-----------------------------------------------
Snapshots the whole project (read-only) before/after and classifies every
file as created/modified/deleted/unchanged.
"""

from .schemas import FileChangeAudit


class FileChangeAuditor:
    def snapshot(self, tool_registry) -> dict:
        listing = tool_registry.impl.list_files(".", recursive=True)
        files = {}
        for path in listing["entries"]:
            try:
                files[path] = tool_registry.impl.read_file(path)["content"]
            except Exception:
                pass
        return files

    def audit(self, before: dict, after: dict) -> FileChangeAudit:
        before_keys, after_keys = set(before), set(after)
        created = sorted(after_keys - before_keys)
        deleted = sorted(before_keys - after_keys)
        common = before_keys & after_keys
        modified = sorted(p for p in common if before[p] != after[p])
        unchanged = sorted(p for p in common if before[p] == after[p])
        return FileChangeAudit(created=created, modified=modified, deleted=deleted, unchanged=unchanged)
