"""
QUALITY CONTROL LAYER — EVIDENCE COLLECTOR
-----------------------------------------------
Read-only by design: only calls read_file/list_files/search_files/
inspect_project/run_tests/run_command (for the optional runtime check) on
the EXISTING ToolRegistry. Never write_file/edit_file - the Quality
Control layer must not modify project files (item 18).
"""

import re
from .schemas import RequirementCheck, RequirementStatus, Severity


class EvidenceCollector:
    READ_ONLY_TOOLS = {"read_file", "list_files", "search_files", "inspect_project", "run_tests", "run_command"}

    def __init__(self, tool_registry):
        self.tool_registry = tool_registry

    def collect(self, requirements, test_command=None) -> dict:
        evidence = {"file_existence": {}, "file_contents": {}, "runtime": None}

        for path in requirements.required_files:
            try:
                content = self.tool_registry.impl.read_file(path)["content"]
                evidence["file_existence"][path] = True
                evidence["file_contents"][path] = content
            except Exception:
                evidence["file_existence"][path] = False

        try:
            evidence["test_result"] = self.tool_registry.impl.run_tests(test_command=test_command)
        except Exception as e:
            evidence["test_result"] = {"passed": False, "stdout": "", "stderr": str(e)}

        try:
            evidence["project_structure"] = self.tool_registry.impl.inspect_project()
        except Exception:
            evidence["project_structure"] = None

        if requirements.entry_command:
            try:
                run = self.tool_registry.impl.run_command(requirements.entry_command, timeout=15)
                evidence["runtime"] = {"command": requirements.entry_command, "returncode": run["returncode"],
                                        "stdout": run["stdout"], "stderr": run["stderr"]}
            except Exception as e:
                evidence["runtime"] = {"command": requirements.entry_command, "returncode": -1, "error": str(e)}

        return evidence

    def check_requirements(self, requirements, evidence) -> list:
        checks = []

        for path in requirements.required_files:
            exists = evidence["file_existence"].get(path, False)
            checks.append(RequirementCheck(
                requirement=f"required file exists: {path}",
                status=RequirementStatus.PASS.value if exists else RequirementStatus.FAIL.value,
                evidence=f"file_existence[{path}]={exists}",
                severity=Severity.HIGH.value,
            ))

        test_stdout = (evidence.get("test_result", {}) or {}).get("stdout", "") or ""
        test_stderr = (evidence.get("test_result", {}) or {}).get("stderr", "") or ""
        combined = test_stdout + "\n" + test_stderr

        for feature in requirements.required_features:
            checks.append(self._check_feature(feature, combined, evidence))

        for test_name in requirements.required_tests:
            checks.append(self._check_named_test(test_name, combined))

        if requirements.entry_command:
            runtime = evidence.get("runtime") or {}
            rc = runtime.get("returncode")
            if rc is None:
                status, ev = RequirementStatus.UNKNOWN.value, "runtime check did not produce a result"
            elif rc == 0:
                status, ev = RequirementStatus.PASS.value, f"'{requirements.entry_command}' exited 0"
            else:
                status, ev = RequirementStatus.FAIL.value, f"'{requirements.entry_command}' exited {rc}: {runtime.get('stderr', '')[:200]}"
            checks.append(RequirementCheck(requirement=f"runtime check: {requirements.entry_command}",
                                            status=status, evidence=ev, severity=Severity.HIGH.value))

        return checks

    def _check_feature(self, feature: str, test_output: str, evidence) -> RequirementCheck:
        test_name_pattern = re.compile(rf'test_\w*{re.escape(feature)}\w*', re.IGNORECASE)
        names_in_output = set(test_name_pattern.findall(test_output))

        if not names_in_output:
            return RequirementCheck(
                requirement=f"feature implemented: {feature}",
                status=RequirementStatus.UNKNOWN.value,
                evidence="no test referencing this feature was found in the test output",
                severity=Severity.MEDIUM.value,
            )

        failed = any(re.search(rf'(FAIL|ERROR): {re.escape(n)}', test_output) for n in names_in_output)
        status = RequirementStatus.FAIL.value if failed else RequirementStatus.PASS.value
        return RequirementCheck(
            requirement=f"feature implemented: {feature}",
            status=status,
            evidence=f"matched test(s): {sorted(names_in_output)}; failed={failed}",
            severity=Severity.HIGH.value,
        )

    def _check_named_test(self, test_name: str, test_output: str) -> RequirementCheck:
        if test_name not in test_output:
            return RequirementCheck(
                requirement=f"required test exists and ran: {test_name}",
                status=RequirementStatus.UNKNOWN.value,
                evidence="test name not found in test run output",
                severity=Severity.MEDIUM.value,
            )
        failed = bool(re.search(rf'(FAIL|ERROR): {re.escape(test_name)}', test_output))
        return RequirementCheck(
            requirement=f"required test passes: {test_name}",
            status=RequirementStatus.FAIL.value if failed else RequirementStatus.PASS.value,
            evidence=f"failed={failed}",
            severity=Severity.HIGH.value,
        )
