"""
ORCHESTRATION LAYER — ORCHESTRATOR
-----------------------------------------
Ties everything together:

    objective -> TaskDecomposer -> SubTasks -> TaskGraph (Phase 1, reused)
        -> ready_batch() each round -> WorkerSelector -> bounded
        ThreadPoolExecutor -> WorkerResult -> SharedTaskState
        -> ResultAggregator -> Critic/TaskVerifier (Phase 4, reused)
        -> QualityGate (Phase 5, reused) -> OrchestrationResult

Real bounded concurrency via concurrent.futures.ThreadPoolExecutor - not
simulated. MAX_TOTAL_WORKERS and MAX_TASK_DEPTH are hard, tested limits
enforced in code, not just documented as a suggestion.
"""

import time
import uuid
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from task_planner import Task, TaskGraph
from agent.events import AgentEventLog
from repair import Critic
from repair.task_verifier import TaskVerifier
from quality.gate import QualityGate
from quality.schemas import CriticResultV2, Severity
from quality.test_integrity import TestIntegrityChecker

from .schemas import WorkerStatus, ResourceLimits, OrchestrationResult, WorkerMessage, WorkerResult
from .shared_state import SharedTaskState
from .decomposer import TaskDecomposer
from .selector import WorkerSelector
from .aggregator import ResultAggregator
from .workers import build_default_registry


def _bridge_to_critic_v2(base_result):
    severity_map = {"blocking": Severity.BLOCKING.value, "minor": Severity.LOW.value, "none": Severity.INFO.value}
    return CriticResultV2(
        approved=base_result.approved,
        issues=[{"issue": i, "severity": severity_map.get(base_result.severity, Severity.MEDIUM.value)} for i in base_result.issues],
        severity=severity_map.get(base_result.severity, Severity.INFO.value),
        evidence=base_result.evidence, confidence={"model_confidence": None, "evidence_confidence": 1.0},
        recommendations=base_result.recommendations,
    )


class Orchestrator:
    def __init__(self, provider, tool_registry, worker_registry=None, project_memory=None, limits=None):
        self.provider = provider
        self.tool_registry = tool_registry
        self.worker_registry = worker_registry or build_default_registry()
        self.project_memory = project_memory
        self.limits = limits or ResourceLimits()
        self.decomposer = TaskDecomposer()
        self.selector = WorkerSelector(self.worker_registry)
        self.aggregator = ResultAggregator()

    def run(self, objective, task_id=None, depth=0, subtasks_override=None):
        task_id = task_id or uuid.uuid4().hex[:12]
        log = AgentEventLog()
        log.emit("ORCHESTRATION_STARTED", task_id, detail=f"depth={depth}")

        if depth > self.limits.max_task_depth:
            log.emit("WORKER_LIMIT_REACHED", task_id, detail=f"max_task_depth={self.limits.max_task_depth} exceeded")
            return OrchestrationResult(task_id=task_id, status="LIMIT_REACHED", events=log.as_dicts())

        subtasks = subtasks_override if subtasks_override is not None else self.decomposer.decompose(task_id, objective)
        for st in subtasks:
            st.depth = depth
        log.emit("TASK_DECOMPOSED", task_id, detail=f"{len(subtasks)} subtasks")

        shared_state = SharedTaskState(task_id=task_id, objective=objective, subtasks=subtasks)
        shared_state.status = "RUNNING"

        graph = TaskGraph()
        for st in subtasks:
            graph.add(Task(id=st.subtask_id, description=st.description, worker_type=None, depends_on=list(st.dependencies)))

        total_workers_started = 0
        limit_hit = False
        messages = []
        perf = {"worker_times": {}, "concurrency_observed": 0}
        active_lock = threading.Lock()
        active_count = {"n": 0}

        def run_one(subtask):
            with active_lock:
                active_count["n"] += 1
                perf["concurrency_observed"] = max(perf["concurrency_observed"], active_count["n"])
            try:
                worker_type, reason = self.selector.select(subtask, self.tool_registry.permissions)
                if worker_type is None:
                    log.emit("WORKER_FAILED", task_id, detail=f"{subtask.subtask_id}: {reason}")
                    return subtask, WorkerResult(worker_id="none", task_id=subtask.subtask_id, status=WorkerStatus.FAILED.value, errors=[reason])

                definition = self.worker_registry.get(worker_type)
                log.emit("WORKER_SELECTED", task_id, detail=f"{subtask.subtask_id} -> {worker_type}")
                log.emit("WORKER_STARTED", task_id, tool_name=worker_type, detail=subtask.subtask_id)

                result = definition.factory(subtask, shared_state, self.tool_registry, self.provider)
                messages.append(WorkerMessage(sender=worker_type, receiver="orchestrator", task_id=subtask.subtask_id,
                                               message_type="RESULT", payload={"status": result.status}))

                if result.status == WorkerStatus.COMPLETED.value:
                    log.emit("WORKER_COMPLETED", task_id, tool_name=worker_type, detail=subtask.subtask_id, success=True)
                else:
                    log.emit("WORKER_FAILED", task_id, tool_name=worker_type, detail=subtask.subtask_id, success=False)

                perf["worker_times"][subtask.subtask_id] = result.execution_time
                return subtask, result
            finally:
                with active_lock:
                    active_count["n"] -= 1

        # Snapshot test files BEFORE any worker runs, so a genuine test-integrity
        # check (Phase 5's real TestIntegrityChecker, reused - not a stub) can
        # run after execution. Without this, a worker weakening/deleting a test
        # to force a false pass would never be caught by this orchestrator's
        # own Quality Gate call.
        integrity_checker = TestIntegrityChecker()
        tests_before_run = integrity_checker.snapshot(self.tool_registry)

        start_time = time.time()
        with ThreadPoolExecutor(max_workers=self.limits.max_concurrent_workers) as pool:
            while not graph.is_complete() and not graph.has_failed() and not limit_hit:
                batch = graph.ready_batch()
                if not batch:
                    break

                startable = []
                for t in batch:
                    if total_workers_started >= self.limits.max_total_workers:
                        log.emit("WORKER_LIMIT_REACHED", task_id, detail=f"max_total_workers={self.limits.max_total_workers}")
                        limit_hit = True
                        break
                    startable.append(t)
                    total_workers_started += 1

                if not startable:
                    break

                subtasks_by_id = {st.subtask_id: st for st in subtasks}
                futures = {}
                for t in startable:
                    graph.mark(t.id, "running")
                    subtask = subtasks_by_id[t.id]
                    futures[pool.submit(run_one, subtask)] = t.id

                for future in as_completed(futures):
                    subtask, result = future.result()
                    shared_state.record_result(subtask.subtask_id, result)
                    subtask.status = "done" if result.status == WorkerStatus.COMPLETED.value else "failed"
                    graph.mark(subtask.subtask_id, subtask.status)

                    if subtask.status == "failed":
                        log.emit("DEPENDENCY_WAIT", task_id, detail=f"{subtask.subtask_id} failed - dependents blocked")

            for t in graph.tasks.values():
                if t.status == "pending":
                    reason = "blocked by failed dependency" if not limit_hit else "worker limit reached"
                    log.emit("DEPENDENCY_WAIT" if not limit_hit else "WORKER_LIMIT_REACHED", task_id, detail=f"{t.id}: {reason}")

        total_time = time.time() - start_time

        log.emit("RESULT_AGGREGATION_STARTED", task_id)
        aggregation = self.aggregator.aggregate(shared_state)
        log.emit("RESULT_AGGREGATED", task_id, detail=f"success={len(aggregation['successful_workers'])} failed={len(aggregation['failed_workers'])}")

        final_test_result = shared_state.test_results[-1] if shared_state.test_results else {"passed": bool(aggregation["successful_workers"]) and not aggregation["failed_workers"]}
        base_critic = Critic().review(objective, aggregation["files_changed"], final_test_result)
        critic_v2 = _bridge_to_critic_v2(base_critic)
        verification = TaskVerifier().verify(self.tool_registry, aggregation["files_changed"], final_test_result)
        tests_after_run = integrity_checker.snapshot(self.tool_registry)
        integrity_result = integrity_checker.check(tests_before_run, tests_after_run)
        if not integrity_result.integrity_ok:
            log.emit("WORKER_FAILED", task_id, detail=f"test integrity violation: {integrity_result.suspicious}")

        gate_decision, reasons = QualityGate().decide(
            requirement_checks=[], test_result=final_test_result, regression_result=None,
            file_audit=None, scope_result=None, integrity_result=integrity_result, critic_result=critic_v2,
        )

        if limit_hit:
            final_status = "LIMIT_REACHED"
        elif aggregation["failed_workers"] or gate_decision.value != "APPROVED":
            final_status = "FAILED"
        else:
            final_status = "COMPLETED"

        shared_state.status = final_status
        if final_status == "COMPLETED":
            log.emit("ORCHESTRATION_COMPLETED", task_id)
        else:
            log.emit("ORCHESTRATION_FAILED", task_id, detail=f"gate={gate_decision.value}")

        result = OrchestrationResult(
            task_id=task_id, status=final_status, subtasks=subtasks,
            worker_results=dict(shared_state.worker_results), aggregation=aggregation,
            quality_decision=gate_decision.value, events=log.as_dicts(),
            performance={**perf, "total_time_seconds": total_time, "total_workers_started": total_workers_started,
                         "subtask_count": len(subtasks)},
        )

        if self.project_memory is not None:
            self._record_memory(result)
        return result

    def _record_memory(self, result):
        summary = {
            "task_id": result.task_id, "status": result.status,
            "subtask_ids": [st.subtask_id for st in result.subtasks],
            "workers_used": sorted({r.worker_id for r in result.worker_results.values()}),
            "worker_results": {sid: {"status": r.status, "files_changed": r.files_changed} for sid, r in result.worker_results.items()},
            "dependencies": {st.subtask_id: st.dependencies for st in result.subtasks},
            "failures": result.aggregation.get("failed_workers", []),
            "final_result": result.status,
        }
        self.project_memory.remember(
            key=f"orchestration:{result.task_id}", value=summary,
            verified=(result.status == "COMPLETED"), source="orchestrator",
        )
