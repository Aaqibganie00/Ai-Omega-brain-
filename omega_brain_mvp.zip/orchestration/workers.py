"""
ORCHESTRATION LAYER — WORKER IMPLEMENTATIONS
----------------------------------------------------
Every worker function has the signature:
    (subtask, shared_state, tool_registry, provider) -> WorkerResult

None of these reimplement logic that already exists:
  - CodingWorker wraps agent.CodingAgentWorker (Phase 3) unmodified.
  - DebuggingWorker wraps repair.AutonomousTaskExecutor (Phase 4) unmodified.
  - ReviewWorker wraps repair.Critic (Phase 4) unmodified.
  - VerificationWorker wraps repair.TaskVerifier (Phase 4) unmodified.
PlannerWorker, ResearchWorker, TestingWorker are new but intentionally
thin - TestingWorker literally just calls the existing run_tests tool.
"""

import time
from tools import ToolCall, Permission
from agent.coding_worker import CodingAgentWorker
from repair import AutonomousTaskExecutor, Critic, TaskVerifier
from providers import AIRequest
from .schemas import WorkerResult, WorkerStatus, WorkerDefinition


def _timed(fn):
    def wrapper(subtask, shared_state, tool_registry, provider):
        start = time.time()
        result = fn(subtask, shared_state, tool_registry, provider)
        result.execution_time = time.time() - start
        return result
    return wrapper


@_timed
def planner_worker(subtask, shared_state, tool_registry, provider):
    resp = provider.generate(AIRequest.simple(f"Plan: {subtask.description}"))
    return WorkerResult(worker_id="planner_worker", task_id=subtask.subtask_id, status=WorkerStatus.COMPLETED.value, output=resp.content)


@_timed
def research_worker(subtask, shared_state, tool_registry, provider):
    resp = provider.generate(AIRequest.simple(f"Research: {subtask.description}"))
    return WorkerResult(worker_id="research_worker", task_id=subtask.subtask_id, status=WorkerStatus.COMPLETED.value, output=resp.content)


@_timed
def coding_worker_adapter(subtask, shared_state, tool_registry, provider):
    worker = CodingAgentWorker(provider=provider, tool_registry=tool_registry)
    session_result = worker.execute_task(subtask.description, task_id=subtask.subtask_id)
    files_changed = sorted({
        c["arguments"].get("path") for c in session_result.tool_calls_made
        if c["success"] and c["tool_name"] in ("write_file", "edit_file") and c["arguments"].get("path")
    })
    status = WorkerStatus.COMPLETED.value if session_result.status == "COMPLETED" else WorkerStatus.FAILED.value
    errors = [] if status == WorkerStatus.COMPLETED.value else [session_result.status]
    return WorkerResult(worker_id="coding_worker", task_id=subtask.subtask_id, status=status,
                         output=session_result.final_response, files_changed=files_changed,
                         tools_used=[c["tool_name"] for c in session_result.tool_calls_made], errors=errors)


@_timed
def testing_worker(subtask, shared_state, tool_registry, provider):
    call = ToolCall(tool_name="run_tests", arguments={})
    result = tool_registry.execute(call)
    shared_state.record_test_result(result.output or {})
    passed = bool((result.output or {}).get("passed"))
    status = WorkerStatus.COMPLETED.value if passed else WorkerStatus.FAILED.value
    errors = [] if passed else [(result.output or {}).get("stderr", "tests failed")[:300]]
    return WorkerResult(worker_id="testing_worker", task_id=subtask.subtask_id, status=status,
                         output=f"tests passed={passed}", tools_used=["run_tests"], errors=errors)


@_timed
def debugging_worker(subtask, shared_state, tool_registry, provider):
    executor = AutonomousTaskExecutor(provider=provider, tool_registry=tool_registry, max_repair_attempts=2)
    exec_result = executor.run(subtask.description, task_id=subtask.subtask_id)
    status = WorkerStatus.COMPLETED.value if exec_result.final_state == "COMPLETED" else WorkerStatus.FAILED.value
    errors = [] if status == WorkerStatus.COMPLETED.value else [exec_result.status_reason]
    return WorkerResult(worker_id="debugging_worker", task_id=subtask.subtask_id, status=status,
                         output=exec_result.status_reason, files_changed=exec_result.files_changed_total, errors=errors)


@_timed
def review_worker(subtask, shared_state, tool_registry, provider):
    test_result = shared_state.test_results[-1] if shared_state.test_results else {"passed": False}
    critic_result = Critic().review(shared_state.objective, sorted(shared_state.files_changed), test_result)
    status = WorkerStatus.COMPLETED.value if critic_result.approved else WorkerStatus.FAILED.value
    return WorkerResult(worker_id="review_worker", task_id=subtask.subtask_id, status=status,
                         output=f"approved={critic_result.approved}", errors=critic_result.issues)


@_timed
def verification_worker(subtask, shared_state, tool_registry, provider):
    test_result = shared_state.test_results[-1] if shared_state.test_results else {"passed": False}
    required_files = sorted(shared_state.files_changed)
    verification = TaskVerifier().verify(tool_registry, required_files, test_result)
    status = WorkerStatus.COMPLETED.value if verification.passed else WorkerStatus.FAILED.value
    return WorkerResult(worker_id="verification_worker", task_id=subtask.subtask_id, status=status,
                         output=verification.detail, tools_used=["read_file"] * len(required_files))


def build_default_registry():
    from .worker_registry import WorkerRegistry
    registry = WorkerRegistry()
    registry.register(WorkerDefinition("planning", {"planning"}, {Permission.READ}, "Produces a short plan.", planner_worker))
    registry.register(WorkerDefinition("research", {"research"}, {Permission.READ}, "Gathers/summarizes information.", research_worker))
    registry.register(WorkerDefinition("coding", {"coding"}, {Permission.READ, Permission.WRITE}, "Implements code via the existing CodingAgentWorker.", coding_worker_adapter))
    registry.register(WorkerDefinition("testing", {"testing"}, {Permission.READ, Permission.EXECUTE}, "Runs the test suite via the existing run_tests tool.", testing_worker))
    registry.register(WorkerDefinition("debugging", {"debugging"}, {Permission.READ, Permission.WRITE, Permission.EXECUTE}, "Repairs failures via the existing Phase 4 executor.", debugging_worker))
    registry.register(WorkerDefinition("review", {"review"}, {Permission.READ}, "Reviews results via the existing Critic.", review_worker))
    registry.register(WorkerDefinition("verification", {"verification"}, {Permission.READ}, "Verifies via the existing TaskVerifier.", verification_worker))
    return registry
